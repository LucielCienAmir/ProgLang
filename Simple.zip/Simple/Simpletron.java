import java.io.*;
import java.util.Scanner;

public class Simpletron {
    private String[] memory;
    private int accumulator;
    private int programCounter;
    private int instructionRegister;
    private int operationCode;
    private int operand;

    public Simpletron() {
        memory = new String[100];
        for (int i = 0; i < memory.length; i++) {
            memory[i] = "0000";
        }
        accumulator = 0;
        programCounter = 0;
        instructionRegister = 0;
        operationCode = 0;
        operand = 0;
    }

    // Add value at address
    public void addItem(int address, String value) {
        if (address >= 0 && address < memory.length) {
            memory[address] = String.format("%04d", Integer.parseInt(value));
        } else {
            System.err.println("Invalid memory address: " + address);
        }
    }

    // Dump registers
    private void dumpRegisters() {
        System.out.printf("accumulator:  %+05d%n", accumulator);
        System.out.printf("programCounter:  %02d%n", programCounter);
        System.out.printf("instructionRegister: %+05d%n", instructionRegister);
        System.out.printf("operationCode:  %02d%n", operationCode);
        System.out.printf("operand:  %02d%n", operand);
    }

    // Dump memory
    private void dumpMemory() {
        System.out.println("MEMORY:");
        System.out.print(" ");
        for (int i = 0; i < 10; i++) {
            System.out.printf("%6d", i);
        }
        System.out.println();
        for (int row = 0; row < 10; row++) {
            System.out.printf("%02d ", row * 10);
            for (int col = 0; col < 10; col++) {
                int index = row * 10 + col;
                int val = Integer.parseInt(memory[index]);
                System.out.printf(" %+05d", val);
            }
            System.out.println();
        }
    }

    // Load program from file
    public void loadProgram(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                String instr = parts[0].trim();
                if (!instr.isEmpty()) {
                    String[] tokens = instr.split("\\s+");
                    if (tokens.length == 2) {
                        int addr = Integer.parseInt(tokens[0]);
                        String val = tokens[1];
                        addItem(addr, val);
                    }
                }
            }
        } catch (IOException e) {
            System.err.println("Error loading program: " + e.getMessage());
        }
    }

    // Run program (fetch–decode–execute)
    public void run() {
        Scanner input = new Scanner(System.in);
        boolean running = true;

        while (running) {
            instructionRegister = Integer.parseInt(memory[programCounter]);
            operationCode = instructionRegister / 100;
            operand = instructionRegister % 100;
            programCounter++;

            switch (operationCode) {
                case 10: // READ
                    System.out.print("? ");
                    int inVal = input.nextInt();
                    memory[operand] = String.format("%04d", inVal);
                    break;
                case 11: // WRITE
                    System.out.println("> " + Integer.parseInt(memory[operand]));
                    break;
                case 20: // LOAD
                    accumulator = Integer.parseInt(memory[operand]);
                    break;
                case 21: // STORE
                    memory[operand] = String.format("%04d", accumulator);
                    break;
                case 30: // ADD
                    accumulator += Integer.parseInt(memory[operand]);
                    break;
                case 31: // SUB
                    accumulator -= Integer.parseInt(memory[operand]);
                    break;
                case 32: // DIV
                    accumulator /= Integer.parseInt(memory[operand]);
                    break;
                case 33: // MOD
                    accumulator %= Integer.parseInt(memory[operand]);
                    break;
                case 34: // MUL
                    accumulator *= Integer.parseInt(memory[operand]);
                    break;
                case 40: // JMP
                    programCounter = operand;
                    break;
                case 41: // JN
                    if (accumulator < 0) programCounter = operand;
                    break;
                case 42: // JZ
                    if (accumulator == 0) programCounter = operand;
                    break;
                case 43: // HALT
                    running = false;
                    break;
                default:
                    System.err.println("Invalid operation code: " + operationCode);
                    running = false;
            }
        }

        dumpRegisters();
        dumpMemory();
    }

    public static void main(String[] args) {
        Simpletron s = new Simpletron();
        s.loadProgram("test.sml");
        s.run();
    }
}
