import java.io.*;
import java.util.*;

public class Simpletron {
    private int pc;
    private int ir;
    private int opcode;
    private int operand;
    private Memory memory;
    private int accumulator;
    private String filename;
    private boolean halted;
    private boolean stepMode;
    private Scanner scanner;
    private StringBuilder outputBuffer = new StringBuilder();

    public Simpletron(String filename, boolean stepMode) {
        this.filename = filename;
        this.pc = 0;
        this.accumulator = 0;
        this.memory = new Memory(100);
        this.halted = false;
        this.stepMode = stepMode;
        this.scanner = new Scanner(System.in);
        loadProgram();
    }

    private void loadProgram() {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                int cidx = line.indexOf(';');
                if (cidx >= 0) line = line.substring(0, cidx);
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] parts = line.split("\\s+");
                if (parts.length < 2) continue;

                try {
                    int address = Integer.parseInt(parts[0]);
                    int instr = Integer.parseInt(parts[1]);
                    memory.store(address, instr);
                } catch (NumberFormatException ex) {
                    Integer addr = null;
                    Integer instr = null;
                    for (String p : parts) {
                        if (addr == null) {
                            try { addr = Integer.parseInt(p); continue; } catch (Exception ignore) {}
                        } else if (instr == null) {
                            try { instr = Integer.parseInt(p); break; } catch (Exception ignore) {}
                        }
                    }
                    if (addr != null && instr != null) {
                        memory.store(addr, instr);
                    }
                }
            }
            System.out.println("*** Welcome to Simpletron ***");
        } catch (FileNotFoundException e) {
            System.err.println("Program file not found: " + filename);
            System.exit(1);
        } catch (IOException e) {
            System.err.println("Error reading program file: " + e.getMessage());
            System.exit(1);
        }
    }

    public void run() {
        if (!stepMode) {
            while (!halted && pc >= 0 && pc < memory.size()) {
                fetch();
                decodeAndExecute();
            }
        } else {
            printRegisters();
            memory.dumpFormatted();
            System.out.println("Press ENTER to start execution...");
            scanner.nextLine();
            while (!halted && pc >= 0 && pc < memory.size()) {
                fetch();
                System.out.printf("Executing %04d...%n", ir);
                decodeAndExecute();
                printRegisters();
                memory.dumpFormatted();
                if (!halted) {
                    System.out.println("Press ENTER to continue...");
                    scanner.nextLine();
                }
            }
        }

        System.out.println("output: " + outputBuffer.toString());
        printRegisters();
        memory.dumpFormatted();
        System.out.println("Program terminated" + (halted ? " normally..." : " (abnormally)."));
    }

    private void fetch() {
        ir = memory.fetchValue(pc);
        pc++;
        int temp = Math.abs(ir);
        opcode = temp / 100;
        operand = temp % 100;
    }

    private void decodeAndExecute() {
        switch (opcode) {
            case 10: {
                System.out.print("Enter an integer:  ");
                String in = scanner.nextLine().trim();
                int v;
                try {
                    v = Integer.parseInt(in);
                } catch (NumberFormatException e) {
                    System.out.println("Invalid integer, storing 0.");
                    v = 0;
                }
                if (v > 9999) v = 9999;
                if (v < -9999) v = -9999;
                memory.store(operand, v);
            } break;

            case 11: {
                int v = memory.fetchValue(operand);
                outputBuffer.append(v);
            } break;

            case 12: {
                outputBuffer.append(accumulator);
            } break;

            case 13: {
                outputBuffer.append(operand);
            } break;

            case 20: {
                accumulator = memory.fetchValue(operand);
            } break;

            case 21: {
                memory.store(operand, accumulator);
            } break;

            case 22: {
                accumulator = operand;
            } break;

            case 30: {
                accumulator = safeAdd(accumulator, memory.fetchValue(operand));
            } break;

            case 31: {
                accumulator = safeSub(accumulator, memory.fetchValue(operand));
            } break;

            case 32: {
                int divisor = memory.fetchValue(operand);
                if (divisor == 0) {
                    System.out.println("Error: Division by zero (DivM). Acc unchanged.");
                } else {
                    accumulator = accumulator / divisor;
                }
            } break;

            case 33: {
                int modBy = memory.fetchValue(operand);
                if (modBy == 0) {
                    System.out.println("Error: Modulo by zero (ModM). Acc unchanged.");
                } else {
                    accumulator = accumulator % modBy;
                }
            } break;

            case 34: {
                accumulator = safeMul(accumulator, memory.fetchValue(operand));
            } break;

            case 35: {
                accumulator = safeAdd(accumulator, operand);
            } break;

            case 36: {
                accumulator = safeSub(accumulator, operand);
            } break;

            case 37: {
                if (operand == 0) {
                    System.out.println("Error: Division by zero (DivI). Acc unchanged.");
                } else {
                    accumulator = accumulator / operand;
                }
            } break;

            case 38: {
                if (operand == 0) {
                    System.out.println("Error: Modulo by zero (ModI). Acc unchanged.");
                } else {
                    accumulator = accumulator % operand;
                }
            } break;

            case 39: {
                accumulator = safeMul(accumulator, operand);
            } break;

            case 40: {
                pc = operand;
            } break;

            case 41: {
                if (accumulator < 0) pc = operand;
            } break;

            case 42: {
                if (accumulator == 0) pc = operand;
            } break;

            case 43: {
                halted = true;
            } break;

            default:
                System.out.println("Unknown opcode: " + opcode + " (IR=" + String.format("%04d", ir) + ")");
                halted = true;
        }

        if (accumulator > 9999) accumulator %= 10000;
        if (accumulator < -9999) accumulator = -((-accumulator) % 10000);
    }

    private int safeAdd(int a, int b) {
        long r = (long) a + b;
        return (int) Math.max(Math.min(r, Integer.MAX_VALUE), Integer.MIN_VALUE);
    }

    private int safeSub(int a, int b) {
        long r = (long) a - b;
        return (int) Math.max(Math.min(r, Integer.MAX_VALUE), Integer.MIN_VALUE);
    }

    private int safeMul(int a, int b) {
        long r = (long) a * b;
        return (int) Math.max(Math.min(r, Integer.MAX_VALUE), Integer.MIN_VALUE);
    }

    private void printRegisters() {
        System.out.println("\nREGISTERS:");
        System.out.println("accumulator:        " + Memory.formatWord(accumulator));
        System.out.printf("programCounter:     %02d%n", pc);
        System.out.printf("instructionRegister: %04d%n", ir);
        System.out.printf("operationCode:      %02d%n", opcode);
        System.out.printf("operand:            %02d%n", operand);
    }

    public static void main(String... args) {
        if (args.length == 0) {
            System.out.println("use: java Simpletron filename.sml [-s]");
            System.out.println("-s : execute one instruction at a time (step mode)");
            return;
        }
        String file = args[0];
        boolean step = args.length > 1 && args[1].equals("-s");

        Simpletron s = new Simpletron(file, step);
        s.run();
    }
}
