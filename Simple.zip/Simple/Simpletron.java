import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Simpletron {
    private String[] memory; // keep lowercase "memory" to avoid confusion

    // Constructor: initializes memory with "0000" and prints it
    public Simpletron() {
        memory = new String[100];
        for (int i = 0; i < memory.length; i++) {
            memory[i] = "0000";
        }
    }

    // Adds (sets) a value at a specific address
    public void addItem(int address, String value) {
        if (address >= 0 && address < memory.length) {
            memory[address] = String.format("%04d", Integer.parseInt(value));
        } else {
            System.err.println("Invalid memory address: " + address);
        }
    }

    // Gets a value at a specific address
    public String getItem(int address) {
        if (address >= 0 && address < memory.length) {
            return memory[address];
        } else {
            System.err.println("Invalid memory address: " + address);
            return null;
        }
    }

    // Prints memory in a table format
    public void Memory() {
        System.out.print("  ");
        for (int colIndex = 0; colIndex < 10; colIndex++) {
            System.out.printf("%5d ", colIndex);
        }
        System.out.println();

        for (int index = 0; index < 100; index++) {
            int rowIndex = index / 10;
            int colIndex = index % 10;

            if (colIndex == 0) {
                System.out.printf("%2d  ", rowIndex);
            }

            String value = memory[index];

            try {
                int intValue = Integer.parseInt(value);
                if (intValue >= 0) {
                    System.out.printf("+%4s ", value);
                } else {
                    System.out.printf("%4s ", value);
                }
            } catch (NumberFormatException e) {
                System.out.printf("%5s ", value);
            }

            if (colIndex == 9) {
                System.out.println();
            }
        }
    }

    // Loads program from a file and then prints the updated memory
    public void dump(String filename) {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";"); // Ignore comments after ";"
                String instruction = parts[0].trim();

                if (!instruction.isEmpty()) {
                    // Example line: "00 1007"
                    String[] tokens = instruction.split("\\s+");
                    if (tokens.length == 2) {
                        int address = Integer.parseInt(tokens[0]);
                        String value = tokens[1];
                        addItem(address, value);
                    }
                }
            }
            Memory();
        } catch (IOException e) {
            System.err.println("Error loading program: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        Simpletron simpletron = new Simpletron();   // Constructor prints initial memory
        simpletron.dump("test.sml");               // Loads program and prints updated memory
    }
}
