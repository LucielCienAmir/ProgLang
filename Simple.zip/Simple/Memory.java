import java.util.Arrays;

public class Memory {
    private int[] mem;

    public Memory(int size) {
        mem = new int[size];
        Arrays.fill(mem, 0);
    }

    public void store(int address, int value) {
        checkAddress(address);
        mem[address] = value;
    }

    public int fetchValue(int address) {
        checkAddress(address);
        return mem[address];
    }

    public int size() {
        return mem.length;
    }

    private void checkAddress(int address) {
        if (address < 0 || address >= mem.length)
            throw new IndexOutOfBoundsException("Memory address out of range: " + address);
    }

    public void dumpFormatted() {
        System.out.println("\nMEMORY:\n");
        for (int row = 0; row < 100; row += 10) {
            System.out.printf("%02d ", row);
            for (int col = 0; col < 10; col++) {
                int idx = row + col;
                System.out.print(formatWord(mem[idx]) + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    public static String formatWord(int value) {
        char sign = value < 0 ? '-' : '+';
        int abs = Math.abs(value);
        if (abs > 9999) abs %= 10000;
        return String.format("%c%04d", sign, abs);
    }
}
