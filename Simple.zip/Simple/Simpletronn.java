import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

class Memory {
    private String[] memory;
    
    public Memory() {
        memory = new String[100];
        // Initialize memory with "0000"
        for (int i = 0; i < memory.length; i++) {
            memory[i] = "0000";
        }
    }

    public void loadFromFile(String fileName) {
        try (BufferedReader br = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                String[] parts = line.split("\\s+"); // Split by whitespace
                
                if (parts.length == 2) {
                    try {
                        // Parse the address and value
                        int address = Integer.parseInt(parts[0]);
                        String value = parts[1];

                        // Ensure the address is within bounds (0-99)
                        if (address >= 0 && address < memory.length) {
                            memory[address] = value;
                        } else {
                            System.err.println("Invalid address: " + address);
                        }
                    } catch (NumberFormatException e) {
                        System.err.println("Invalid number format in line: " + line);
                    }
                } else {
                    System.err.println("Incorrect format in line: " + line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage());
        }
    }

    // Method to get the value at a specific index
    public String getValue(int index) {
        return memory[index];
    }

    // Method to print the memory in the 10x10 format
    public void printMemory() {
        System.out.println("\nMEMORY:");
        // Print column headers
        System.out.print("     ");
        for (int colIndex = 0; colIndex < 10; colIndex++) {
            System.out.printf("%6d", colIndex); // Column header
        }
        System.out.println();

        // Print the rows and memory values
        for (int rowIndex = 0; rowIndex < 10; rowIndex++) {
            System.out.print(rowIndex + "   ");  // Row header
            for (int colIndex = 0; colIndex < 10; colIndex++) {
                int index = rowIndex * 10 + colIndex;
                String value = memory[index];
                // Check for the positive value and format it
                if (Integer.parseInt(value) >= 0) {
                    System.out.print("+" + value + " ");  // Add "+" for positive numbers
                } else {
                    System.out.print(value + " ");  // Print negative values as is
                }
            }
            System.out.println();
        }
    }
}

// Simpletron Class: The main class that represents the Simpletron machine
public class Simpletronn {
    private Memory memory;

    // Constructor
    public Simpletronn() {
        memory = new Memory();
    }

    // Method to load memory from a file
    public void loadMemory(String fileName) {
        memory.loadFromFile(fileName);
    }

    // Method to print the memory
    public void printMemory() {
        memory.printMemory();
    }

    public static void main(String[] args) {
        Simpletronn simpletron = new Simpletronn();
        simpletron.loadMemory("memory.txt");
        simpletron.printMemory();
    }
}
